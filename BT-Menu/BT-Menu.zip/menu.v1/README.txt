#############################################################################################
NOTE : LOGIN INTO ROOT PRIVILEGE USER AND THEN DO NEXT STEPS .
##############################################################################################
 
How to install back-track tools in Ubuntu ?

(1). start backtrack-tools script first with terminal,
   
   command ---> sudo bash backtrack-tools

(2). Go on system -> administration -> synaptic package manager   &&  install backtrack tools ,

(3) Edit the applications.menu :  gedit /etc/xdg/menus/applications.menu
    find "Games" on application.menu file & before "Games" copy and paste the contant of "file.txt" !!!! 

 NOTE: This script only tested on ubuntu 9.10,10.04,10.10.
